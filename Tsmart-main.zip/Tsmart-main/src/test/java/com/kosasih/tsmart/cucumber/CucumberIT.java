package com.kosasih.tsmart.cucumber;

import com.kosasih.tsmart.IntegrationTest;
import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
@IntegrationTest
class CucumberIT {}
