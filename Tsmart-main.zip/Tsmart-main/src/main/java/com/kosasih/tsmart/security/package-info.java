/**
 * Application security utilities.
 */
package com.kosasih.tsmart.security;
