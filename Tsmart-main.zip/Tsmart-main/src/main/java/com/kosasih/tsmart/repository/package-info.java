/**
 * Repository layer.
 */
package com.kosasih.tsmart.repository;
