/**
 * Rest layer error handling.
 */
package com.kosasih.tsmart.web.rest.errors;
