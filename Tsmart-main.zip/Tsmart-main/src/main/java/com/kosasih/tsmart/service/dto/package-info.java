/**
 * Data transfer objects for rest mapping.
 */
package com.kosasih.tsmart.service.dto;
