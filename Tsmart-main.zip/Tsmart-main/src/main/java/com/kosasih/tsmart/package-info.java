/**
 * Application root.
 */
package com.kosasih.tsmart;
