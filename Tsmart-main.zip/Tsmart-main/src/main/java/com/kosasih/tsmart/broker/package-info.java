/**
 * Spring cloud consumers and providers
 */
package com.kosasih.tsmart.broker;
