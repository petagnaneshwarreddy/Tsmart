/**
 * Rest layer.
 */
package com.kosasih.tsmart.web.rest;
