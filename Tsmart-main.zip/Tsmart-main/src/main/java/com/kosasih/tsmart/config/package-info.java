/**
 * Application configuration.
 */
package com.kosasih.tsmart.config;
