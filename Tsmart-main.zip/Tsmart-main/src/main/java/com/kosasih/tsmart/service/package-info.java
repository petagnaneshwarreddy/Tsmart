/**
 * Service layer.
 */
package com.kosasih.tsmart.service;
