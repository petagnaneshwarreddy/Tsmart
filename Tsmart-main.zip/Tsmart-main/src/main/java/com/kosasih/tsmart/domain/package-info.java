/**
 * Domain objects.
 */
package com.kosasih.tsmart.domain;
