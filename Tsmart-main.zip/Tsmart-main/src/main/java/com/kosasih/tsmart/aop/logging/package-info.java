/**
 * Logging aspect.
 */
package com.kosasih.tsmart.aop.logging;
