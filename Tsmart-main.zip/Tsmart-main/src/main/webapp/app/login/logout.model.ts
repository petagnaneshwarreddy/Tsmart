export class Logout {
  constructor(public logoutUrl: string) {}
}
